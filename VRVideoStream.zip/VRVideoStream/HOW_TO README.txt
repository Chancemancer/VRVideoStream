Thankyou for Downloading the VR video streaming project. 

This is an experimental program for a Virtual reality application that contains windows for displaying HTML5 content.

Using the IPWebcam application, the video stream from the localhost can be retrieved and loaded into this application by replacing your URL(s) with the URLs found in this program.
Additionally, the last frame of a video stream can be input into this program as well, when the user is not looking at a screen.

Once these are set up, start an npm server (must have node.js installed/setup) in the VRVideoStream folder and type into the Samsung browser the url as follows: 
	http://"URL PROVIDED BY NPM"/webvr-bolierplate-master/

Simply press the enter VR button and place in a Gear VR headset.